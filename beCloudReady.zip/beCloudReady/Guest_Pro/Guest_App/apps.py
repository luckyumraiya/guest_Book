from django.apps import AppConfig


class GuestAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Guest_App'
