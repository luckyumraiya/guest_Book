from django.db import models

# Create your models here.

class guest(models.Model):
    guest_no = models.IntegerField()
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    contact = models.IntegerField()
    city = models.CharField(max_length=64)
    state = models.CharField(max_length=66)

