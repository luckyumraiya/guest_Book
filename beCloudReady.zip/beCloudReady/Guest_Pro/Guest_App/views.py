from django.shortcuts import render,redirect
from .models import guest

# Create your views here.

def INDEX(request):
    gs= guest.objects.all()

    context={
        'gs':gs,
    }
    return render(request,'index.html',context)

def ADD(request):
    if request.method=="POST":
        guestno = request.POST.get('guestno')
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        contact =  request.POST.get('contact')
        city = request.POST.get('city')
        state = request.POST.get('state')

        gs = guest(

            guest_no = guestno,
            first_name = firstname,
            last_name = lastname,
            contact = contact,
            city = city,
            state = state
        )
        gs.save()
        return redirect('home')

    return render(request,'index.html')

def Edit(request):
    gs = guest.objects.all()

    context = {
        'gs': gs,
    }
    return redirect(request, 'index.html',context)

def Update(request,id):
    if request.method=="POST":
        guestno = request.POST.get('guestno')
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        contact = request.POST.get('contact')
        city = request.POST.get('city')
        state = request.POST.get('state')

        gs = guest(

            id = id,
            guest_no = guestno,
            first_name = firstname,
            last_name = lastname,
            contact = contact,
            city = city,
            state = state
        )
        gs.save()

        return redirect('home')

    return redirect(request, 'index.html')

def Delete(request,id):
    gs = guest.objects.filter(id = id)
    gs.delete()

    context = {
        'gs': gs,
    }
    return redirect('home')


