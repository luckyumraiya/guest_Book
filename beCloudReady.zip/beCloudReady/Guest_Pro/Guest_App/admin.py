from django.contrib import admin
from . models  import guest

# Register your models here.

class GuestAdmin(admin.ModelAdmin):
         list_display = ['id','guest_no', 'first_name', 'last_name', 'contact','city','state']
admin.site.register(guest,GuestAdmin)
